﻿namespace My_Project {
    public class Circle {
        public Circle(double Circumference) {
            CircleCircumference = CircleCircumference;
        }

        public double CircleCircumference;
        public static double CalculateDiameter(double Radius) {
            return Radius * 2;
        }
    }
}