﻿using System;

namespace My_Project {
    public partial class controlstest : System.Web.UI.Page {
        protected void Page_Load(object sender, EventArgs e) {

        }
    }
}