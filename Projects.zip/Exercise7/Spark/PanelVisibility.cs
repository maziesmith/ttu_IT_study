﻿namespace Spark {
    public enum PanelVisibility {
        Visible = 0,
        Hidden
    };
}