﻿namespace Spark {
    public static class Utilities {

    }
}
